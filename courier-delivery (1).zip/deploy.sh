#!/bin/bash

# Speedy Courier - Automated Deployment Script
# This script automates the deployment process to Vercel

echo "🚚 Speedy Courier - Deployment Script"
echo "======================================"

# Check if required tools are installed
command -v node >/dev/null 2>&1 || { echo "❌ Node.js is required but not installed. Aborting." >&2; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "❌ npm is required but not installed. Aborting." >&2; exit 1; }

echo "✅ Node.js and npm are installed"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if build passes
echo "🔨 Testing build..."
npm run build

if [ $? -eq 0 ]; then
    echo "✅ Build successful"
else
    echo "❌ Build failed. Please fix errors before deploying."
    exit 1
fi

# Check if Vercel CLI is installed
if ! command -v vercel &> /dev/null; then
    echo "📥 Installing Vercel CLI..."
    npm install -g vercel
fi

echo "🚀 Starting deployment to Vercel..."

# Deploy to Vercel
vercel --prod

echo ""
echo "🎉 Deployment completed!"
echo ""
echo "📋 Next Steps:"
echo "1. Set up environment variables in Vercel dashboard"
echo "2. Configure Google Analytics"
echo "3. Set up SendGrid for email notifications"
echo "4. Add custom domain (optional)"
echo ""
echo "📖 See DEPLOYMENT.md for detailed instructions"
echo ""
echo "🌐 Your site should be live at the URL provided above"
