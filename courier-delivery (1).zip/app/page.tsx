"use client"

import { useState, useEffect } from "react"
import { Search, Package, Truck, Clock, MapPin, Phone, Mail, Shield, Globe, Zap, ArrowRight, Star, CheckCircle, Bell } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { SpeedyCourierLogo } from "@/components/speedy-courier-logo"
import { trackEvent, trackPackageTracking, trackServiceQuote } from "@/components/google-analytics"
import { useToast } from "@/hooks/use-toast"

// Mock tracking data
const trackingData = {
  "FX123456789": {
    status: "In Transit",
    statusColor: "bg-blue-500",
    from: "New York, NY",
    to: "Los Angeles, CA",
    estimatedDelivery: "Tomorrow by 10:30 AM",
    weight: "2.5 lbs",
    service: "Express Overnight",
    customerEmail: "john.doe@email.com",
    customerName: "John Doe",
    trackingEvents: [
      { time: "2:15 PM", date: "Today", location: "Phoenix, AZ", status: "In transit", description: "Package is on the way" },
      { time: "8:30 AM", date: "Today", location: "Denver, CO", status: "In transit", description: "Departed facility" },
      { time: "11:45 PM", date: "Yesterday", location: "Chicago, IL", status: "In transit", description: "Arrived at facility" },
      { time: "6:20 PM", date: "Yesterday", location: "New York, NY", status: "Picked up", description: "Package picked up" }
    ]
  },
  "FX987654321": {
    status: "Delivered",
    statusColor: "bg-green-500",
    from: "Miami, FL",
    to: "Atlanta, GA",
    estimatedDelivery: "Delivered at 2:45 PM",
    weight: "1.2 lbs",
    service: "Ground",
    customerEmail: "jane.smith@email.com",
    customerName: "Jane Smith",
    trackingEvents: [
      { time: "2:45 PM", date: "Today", location: "Atlanta, GA", status: "Delivered", description: "Left at front door" },
      { time: "9:15 AM", date: "Today", location: "Atlanta, GA", status: "Out for delivery", description: "On delivery vehicle" },
      { time: "5:30 AM", date: "Today", location: "Atlanta, GA", status: "At facility", description: "At local facility" }
    ]
  }
}

// Customer testimonials
const testimonials = [
  {
    name: "Sarah Johnson",
    company: "Tech Startup Inc.",
    rating: 5,
    text: "Speedy Courier has been our go-to delivery service for over 2 years. Their reliability and customer service are unmatched!",
    image: "/placeholder.svg?height=60&width=60"
  },
  {
    name: "Michael Chen",
    company: "E-commerce Store",
    rating: 5,
    text: "Fast delivery times and excellent tracking system. Our customers love the real-time updates!",
    image: "/placeholder.svg?height=60&width=60"
  },
  {
    name: "Emily Rodriguez",
    company: "Medical Supplies Co.",
    rating: 5,
    text: "When we need critical medical supplies delivered urgently, Speedy Courier always delivers on time.",
    image: "/placeholder.svg?height=60&width=60"
  }
]

export default function CourierDelivery() {
  const [trackingNumber, setTrackingNumber] = useState("")
  const [trackingResult, setTrackingResult] = useState(null)
  const [isTracking, setIsTracking] = useState(false)
  const [currentTestimonial, setCurrentTestimonial] = useState(0)
  const { toast } = useToast()

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const sendNotification = async (type: string, data: any) => {
    try {
      const response = await fetch('/api/notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ type, data }),
      })

      const result = await response.json()
      
      if (result.success) {
        toast({
          title: "📧 Email Notification Sent",
          description: "Customer has been notified about the package update.",
        })
      }
    } catch (error) {
      console.error('Failed to send notification:', error)
    }
  }

  const handleTrack = async () => {
    setIsTracking(true)
    
    // Track analytics event
    trackEvent('track_package_attempt', 'tracking', trackingNumber)
    
    setTimeout(async () => {
      const result = trackingData[trackingNumber] || null
      setTrackingResult(result)
      setIsTracking(false)
      
      if (result) {
        // Track successful tracking
        trackPackageTracking(trackingNumber, result.status)
        
        // Send email notification for package tracking
        await sendNotification('package_update', {
          trackingNumber: trackingNumber,
          status: result.status,
          location: result.trackingEvents[0]?.location || 'Unknown',
          timestamp: new Date().toLocaleString(),
          description: result.trackingEvents[0]?.description || 'Package update',
          customerEmail: result.customerEmail,
          customerName: result.customerName
        })
        
        // If delivered, send delivery confirmation
        if (result.status === 'Delivered') {
          await sendNotification('delivery_confirmation', {
            trackingNumber: trackingNumber,
            status: result.status,
            location: result.trackingEvents[0]?.location || 'Delivered',
            timestamp: new Date().toLocaleString(),
            description: result.trackingEvents[0]?.description || 'Package delivered',
            customerEmail: result.customerEmail,
            customerName: result.customerName
          })
        }
        
        toast({
          title: "📦 Package Found!",
          description: `Status: ${result.status}. Email notification sent to customer.`,
        })
      } else {
        trackEvent('track_package_not_found', 'tracking', trackingNumber)
        toast({
          title: "❌ Package Not Found",
          description: "Please check your tracking number and try again.",
          variant: "destructive"
        })
      }
    }, 1000)
  }

  const handleQuickTrack = (trackingId: string) => {
    setTrackingNumber(trackingId)
    setTimeout(() => handleTrack(), 100)
  }

  const handleServiceQuote = (serviceType: string) => {
    trackServiceQuote(serviceType)
    toast({
      title: "📋 Quote Request",
      description: `Quote request for ${serviceType} service has been submitted.`,
    })
  }

  const handleNewsletterSignup = async (email: string) => {
    trackEvent('newsletter_signup', 'engagement', email)
    
    // Send welcome email
    await sendNotification('admin_alert', {
      message: 'New Newsletter Signup',
      details: { email, timestamp: new Date().toISOString() }
    })
    
    toast({
      title: "✅ Subscribed!",
      description: "You've been subscribed to our newsletter.",
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <SpeedyCourierLogo className="h-10" />
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#services" className="text-gray-600 hover:text-blue-600 transition-colors">Services</a>
              <a href="#tracking" className="text-gray-600 hover:text-blue-600 transition-colors">Tracking</a>
              <a href="#about" className="text-gray-600 hover:text-blue-600 transition-colors">About</a>
              <a href="#contact" className="text-gray-600 hover:text-blue-600 transition-colors">Contact</a>
              <Button variant="outline">Sign In</Button>
              <Button onClick={() => handleServiceQuote('General')}>Get Quote</Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="hero" className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="/courier-trucks-motion.png" 
            alt="Courier delivery service" 
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-5xl font-bold mb-6 animate-fade-in">Fast, Reliable Delivery Worldwide</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Track your packages in real-time and enjoy secure, on-time delivery to over 220 countries and territories.
          </p>
          
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-3xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">220+</div>
              <div className="text-sm opacity-90">Countries Served</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">99.5%</div>
              <div className="text-sm opacity-90">On-Time Delivery</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold mb-2">24/7</div>
              <div className="text-sm opacity-90">Customer Support</div>
            </div>
          </div>
          
          {/* Tracking Section */}
          <div className="max-w-2xl mx-auto">
            <Card className="bg-white text-gray-900">
              <CardHeader>
                <CardTitle className="text-2xl">Track Your Package</CardTitle>
                <CardDescription>Enter your tracking number to get real-time updates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 mb-4">
                  <Input
                    placeholder="Enter tracking number (try: FX123456789 or FX987654321)"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={handleTrack} disabled={isTracking || !trackingNumber}>
                    {isTracking ? <Clock className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                    Track
                  </Button>
                </div>
                <div className="flex gap-2 justify-center">
                  <Button 
                    variant="link" 
                    size="sm" 
                    onClick={() => handleQuickTrack("FX123456789")}
                    className="text-xs"
                  >
                    Try: FX123456789
                  </Button>
                  <Button 
                    variant="link" 
                    size="sm" 
                    onClick={() => handleQuickTrack("FX987654321")}
                    className="text-xs"
                  >
                    Try: FX987654321
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Tracking Results */}
      {trackingResult && (
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <Card className="max-w-4xl mx-auto shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl flex items-center gap-2">
                      Tracking Details
                      <Bell className="h-5 w-5 text-blue-600" />
                    </CardTitle>
                    <CardDescription>Tracking Number: {trackingNumber} • Email notifications enabled</CardDescription>
                  </div>
                  <Badge className={`${trackingResult.statusColor} text-white`}>
                    {trackingResult.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Package Info */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Shipment Details</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">From:</span>
                          <span>{trackingResult.from}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">To:</span>
                          <span>{trackingResult.to}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Service:</span>
                          <span>{trackingResult.service}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Weight:</span>
                          <span>{trackingResult.weight}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-semibold text-lg mb-2">Delivery Information</h3>
                      <div className="flex items-center space-x-2 text-sm mb-2">
                        <Truck className="h-4 w-4 text-blue-600" />
                        <span>{trackingResult.estimatedDelivery}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-green-600">
                        <Bell className="h-4 w-4" />
                        <span>Email notifications sent to {trackingResult.customerEmail}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Tracking Timeline */}
                <div>
                  <h3 className="font-semibold text-lg mb-4">Tracking History</h3>
                  <div className="space-y-4">
                    {trackingResult.trackingEvents.map((event, index) => (
                      <div key={index} className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          <div className={`w-3 h-3 rounded-full ${index === 0 ? 'bg-blue-600' : 'bg-gray-300'}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">{event.status}</p>
                              <p className="text-sm text-gray-600">{event.description}</p>
                            </div>
                            <div className="text-right text-sm text-gray-500">
                              <p>{event.time}</p>
                              <p>{event.date}</p>
                            </div>
                          </div>
                          <div className="flex items-center mt-1 text-sm text-gray-500">
                            <MapPin className="h-3 w-3 mr-1" />
                            {event.location}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {trackingNumber && !trackingResult && !isTracking && (
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <Card className="max-w-2xl mx-auto text-center">
              <CardContent className="py-8">
                <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Tracking Number Not Found</h3>
                <p className="text-gray-600 mb-4">
                  Please check your tracking number and try again.
                </p>
                <div className="flex gap-2 justify-center">
                  <Button 
                    variant="outline" 
                    onClick={() => handleQuickTrack("FX123456789")}
                  >
                    Try Demo: FX123456789
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleQuickTrack("FX987654321")}
                  >
                    Try Demo: FX987654321
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Services Section */}
      <section id="services" className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Services</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Choose from our range of delivery options to meet your specific needs
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-48 overflow-hidden">
                <img 
                  src="/speeding-delivery-truck.png" 
                  alt="Express overnight delivery" 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <Zap className="h-12 w-12 text-blue-600 mb-4" />
                <CardTitle>Express Overnight</CardTitle>
                <CardDescription>Next business day delivery by 10:30 AM</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm mb-4">
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> Money-back guarantee</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> Real-time tracking</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> Signature required</li>
                </ul>
                <Button className="w-full" onClick={() => handleServiceQuote('Express Overnight')}>
                  Get Quote <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>

            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-48 overflow-hidden">
                <img 
                  src="/delivery-truck-loading.png" 
                  alt="Ground delivery service" 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <Truck className="h-12 w-12 text-green-600 mb-4" />
                <CardTitle>Ground Delivery</CardTitle>
                <CardDescription>Reliable delivery within 1-5 business days</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm mb-4">
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> Cost-effective option</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> Full tracking visibility</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> Delivery confirmation</li>
                </ul>
                <Button className="w-full" variant="outline" onClick={() => handleServiceQuote('Ground Delivery')}>
                  Get Quote <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>

            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-48 overflow-hidden">
                <img 
                  src="/international-shipping-airplane.png" 
                  alt="International delivery service" 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <Globe className="h-12 w-12 text-purple-600 mb-4" />
                <CardTitle>International</CardTitle>
                <CardDescription>Worldwide delivery to 220+ countries</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm mb-4">
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> Customs clearance</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> Door-to-door service</li>
                  <li className="flex items-center"><CheckCircle className="h-4 w-4 text-green-500 mr-2" /> International tracking</li>
                </ul>
                <Button className="w-full" variant="outline" onClick={() => handleServiceQuote('International')}>
                  Get Quote <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Customer Testimonials */}
      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What Our Customers Say</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Don't just take our word for it - hear from our satisfied customers
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <Card className="p-8 text-center">
              <CardContent>
                <div className="flex justify-center mb-4">
                  {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <blockquote className="text-lg italic mb-6">
                  "{testimonials[currentTestimonial].text}"
                </blockquote>
                <div className="flex items-center justify-center space-x-4">
                  <img 
                    src={testimonials[currentTestimonial].image || "/placeholder.svg"} 
                    alt={testimonials[currentTestimonial].name}
                    className="w-12 h-12 rounded-full"
                  />
                  <div>
                    <div className="font-semibold">{testimonials[currentTestimonial].name}</div>
                    <div className="text-sm text-gray-600">{testimonials[currentTestimonial].company}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <div className="flex justify-center mt-6 space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentTestimonial ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Products Showcase */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What We Deliver</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              From small packages to large freight, we handle all your shipping needs with care and precision
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center group">
              <div className="h-32 w-32 mx-auto mb-4 rounded-lg overflow-hidden group-hover:shadow-lg transition-shadow">
                <img 
                  src="/placeholder-xaixi.png" 
                  alt="Small packages" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="font-semibold">Small Packages</h3>
              <p className="text-sm text-gray-600">Documents, gifts, and small items</p>
            </div>
            
            <div className="text-center group">
              <div className="h-32 w-32 mx-auto mb-4 rounded-lg overflow-hidden group-hover:shadow-lg transition-shadow">
                <img 
                  src="/placeholder-4d8x5.png" 
                  alt="Medium parcels" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="font-semibold">Medium Parcels</h3>
              <p className="text-sm text-gray-600">Electronics, clothing, and household items</p>
            </div>
            
            <div className="text-center group">
              <div className="h-32 w-32 mx-auto mb-4 rounded-lg overflow-hidden group-hover:shadow-lg transition-shadow">
                <img 
                  src="/freight-boxes-packages.png" 
                  alt="Large freight" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="font-semibold">Large Freight</h3>
              <p className="text-sm text-gray-600">Furniture, appliances, and bulk items</p>
            </div>
            
            <div className="text-center group">
              <div className="h-32 w-32 mx-auto mb-4 rounded-lg overflow-hidden group-hover:shadow-lg transition-shadow">
                <img 
                  src="/fragile-valuable-handling.png" 
                  alt="Special handling" 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="font-semibold">Special Handling</h3>
              <p className="text-sm text-gray-600">Fragile, valuable, and temperature-sensitive items</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="about" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Speedy Courier?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We're committed to providing the best delivery experience with cutting-edge technology and exceptional service
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="h-24 w-24 mx-auto mb-4 rounded-full overflow-hidden bg-blue-50 flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                <Shield className="h-12 w-12 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Secure & Safe</h3>
              <p className="text-gray-600">Your packages are protected with comprehensive insurance and secure handling protocols.</p>
            </div>
            
            <div className="text-center group">
              <div className="h-24 w-24 mx-auto mb-4 rounded-full overflow-hidden bg-green-50 flex items-center justify-center group-hover:bg-green-100 transition-colors">
                <Clock className="h-12 w-12 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">On-Time Delivery</h3>
              <p className="text-gray-600">99.5% on-time delivery rate with real-time tracking and proactive updates.</p>
            </div>
            
            <div className="text-center group">
              <div className="h-24 w-24 mx-auto mb-4 rounded-full overflow-hidden bg-purple-50 flex items-center justify-center group-hover:bg-purple-100 transition-colors">
                <Bell className="h-12 w-12 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Smart Notifications</h3>
              <p className="text-gray-600">Automated email alerts keep you informed at every step of your delivery journey.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Stay Updated with Speedy Courier</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Get the latest updates on shipping rates, new services, and delivery tips
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Input
              placeholder="Enter your email address"
              className="bg-white text-gray-900"
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  const email = e.target.value
                  if (email) {
                    handleNewsletterSignup(email)
                    e.target.value = ''
                  }
                }
              }}
            />
            <Button 
              variant="secondary"
              onClick={(e) => {
                const input = e.target.parentElement.querySelector('input')
                const email = input?.value
                if (email) {
                  handleNewsletterSignup(email)
                  input.value = ''
                }
              }}
            >
              Subscribe
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <SpeedyCourierLogo className="h-8" variant="white" />
              </div>
              <p className="text-gray-400 mb-4">Fast, reliable delivery worldwide with real-time tracking and smart notifications.</p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Facebook</a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Twitter</a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">LinkedIn</a>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Express Delivery</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Ground Shipping</a></li>
                <li><a href="#" className="hover:text-white transition-colors">International</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Freight</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Track Package</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Claims</a></li>
                <li><a href="/admin/login" className="hover:text-white transition-colors">Admin Portal</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <div className="space-y-2 text-gray-400">
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span>1-800-SPEEDY-1</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span>support@speedycourier.com</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4" />
                  <span>New York, NY 10001</span>
                </div>
              </div>
            </div>
          </div>
          
          <Separator className="my-8 bg-gray-700" />
          
          <div className="flex flex-col md:flex-row justify-between items-center text-gray-400 text-sm">
            <p>&copy; 2024 Speedy Courier. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
