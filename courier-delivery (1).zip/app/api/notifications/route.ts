import { NextRequest, NextResponse } from 'next/server'
import { emailService } from '@/lib/email-service'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, data } = body

    let success = false

    switch (type) {
      case 'package_update':
        success = await emailService.sendPackageUpdateNotification(data)
        break
      
      case 'delivery_confirmation':
        success = await emailService.sendDeliveryConfirmation(data)
        break
      
      case 'admin_alert':
        success = await emailService.sendAdminAlert(data.message, data.details)
        break
      
      default:
        return NextResponse.json(
          { success: false, error: 'Invalid notification type' },
          { status: 400 }
        )
    }

    return NextResponse.json({ 
      success, 
      message: success ? 'Notification sent' : 'Failed to send notification' 
    })

  } catch (error) {
    console.error('Notification API error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
