// Email notification service
export interface EmailNotification {
  to: string
  subject: string
  html: string
  trackingNumber?: string
  customerName?: string
}

export interface PackageUpdate {
  trackingNumber: string
  status: string
  location: string
  timestamp: string
  description: string
  customerEmail: string
  customerName: string
}

// Mock email service - replace with actual email provider (SendGrid, AWS SES, etc.)
class EmailService {
  private apiKey: string
  private fromEmail: string

  constructor() {
    this.apiKey = process.env.EMAIL_API_KEY || ''
    this.fromEmail = process.env.FROM_EMAIL || 'notifications@speedycourier.com'
  }

  async sendEmail(notification: EmailNotification): Promise<boolean> {
    try {
      // In production, replace this with actual email service
      console.log('Sending email:', notification)
      
      // Skip actual email sending if no API key is configured
      if (!this.apiKey) {
        console.log('Email API key not configured, skipping email send')
        return true
      }
      
      // Simulate API call to email service
      const response = await fetch('/api/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          from: this.fromEmail,
          ...notification
        })
      })

      return response.ok
    } catch (error) {
      console.error('Email sending failed:', error)
      return false
    }
  }

  async sendPackageUpdateNotification(update: PackageUpdate): Promise<boolean> {
    const emailTemplate = this.generatePackageUpdateTemplate(update)
    
    return await this.sendEmail({
      to: update.customerEmail,
      subject: `Package Update: ${update.trackingNumber} - ${update.status}`,
      html: emailTemplate,
      trackingNumber: update.trackingNumber,
      customerName: update.customerName
    })
  }

  async sendDeliveryConfirmation(update: PackageUpdate): Promise<boolean> {
    const emailTemplate = this.generateDeliveryConfirmationTemplate(update)
    
    return await this.sendEmail({
      to: update.customerEmail,
      subject: `Package Delivered: ${update.trackingNumber}`,
      html: emailTemplate,
      trackingNumber: update.trackingNumber,
      customerName: update.customerName
    })
  }

  async sendAdminAlert(message: string, details: any): Promise<boolean> {
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@speedycourier.com'
    
    return await this.sendEmail({
      to: adminEmail,
      subject: `Speedy Courier Admin Alert: ${message}`,
      html: this.generateAdminAlertTemplate(message, details)
    })
  }

  private generatePackageUpdateTemplate(update: PackageUpdate): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Package Update - Speedy Courier</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .status-badge { 
            display: inline-block; 
            padding: 8px 16px; 
            border-radius: 20px; 
            color: white; 
            font-weight: bold;
            background: #2563eb;
          }
          .tracking-info { background: white; padding: 15px; border-radius: 8px; margin: 15px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          .button { 
            display: inline-block; 
            padding: 12px 24px; 
            background: #2563eb; 
            color: white; 
            text-decoration: none; 
            border-radius: 6px; 
            margin: 10px 0;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>📦 Package Update</h1>
            <p>Your package is on the move!</p>
          </div>
          
          <div class="content">
            <p>Hello ${update.customerName},</p>
            
            <p>We have an update on your package:</p>
            
            <div class="tracking-info">
              <h3>Tracking Number: ${update.trackingNumber}</h3>
              <p><strong>Status:</strong> <span class="status-badge">${update.status}</span></p>
              <p><strong>Location:</strong> ${update.location}</p>
              <p><strong>Time:</strong> ${update.timestamp}</p>
              <p><strong>Details:</strong> ${update.description}</p>
            </div>
            
            <p>You can track your package in real-time by clicking the button below:</p>
            
            <a href="https://speedycourier.com/?track=${update.trackingNumber}" class="button">
              Track Your Package
            </a>
            
            <p>Thank you for choosing Speedy Courier!</p>
          </div>
          
          <div class="footer">
            <p>© 2024 Speedy Courier. All rights reserved.</p>
            <p>If you have any questions, contact us at support@speedycourier.com</p>
          </div>
        </div>
      </body>
      </html>
    `
  }

  private generateDeliveryConfirmationTemplate(update: PackageUpdate): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Package Delivered - Speedy Courier</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #10b981; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .success-badge { 
            display: inline-block; 
            padding: 8px 16px; 
            border-radius: 20px; 
            color: white; 
            font-weight: bold;
            background: #10b981;
          }
          .delivery-info { background: white; padding: 15px; border-radius: 8px; margin: 15px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          .rating { text-align: center; margin: 20px 0; }
          .star { color: #fbbf24; font-size: 24px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>✅ Package Delivered!</h1>
            <p>Your package has been successfully delivered</p>
          </div>
          
          <div class="content">
            <p>Hello ${update.customerName},</p>
            
            <p>Great news! Your package has been delivered successfully.</p>
            
            <div class="delivery-info">
              <h3>Tracking Number: ${update.trackingNumber}</h3>
              <p><strong>Status:</strong> <span class="success-badge">Delivered</span></p>
              <p><strong>Delivered to:</strong> ${update.location}</p>
              <p><strong>Delivery Time:</strong> ${update.timestamp}</p>
              <p><strong>Details:</strong> ${update.description}</p>
            </div>
            
            <div class="rating">
              <h3>How was your delivery experience?</h3>
              <p>Rate us: <span class="star">⭐⭐⭐⭐⭐</span></p>
              <a href="https://speedycourier.com/feedback?tracking=${update.trackingNumber}" style="color: #2563eb;">Leave Feedback</a>
            </div>
            
            <p>Thank you for choosing Speedy Courier for your delivery needs!</p>
          </div>
          
          <div class="footer">
            <p>© 2024 Speedy Courier. All rights reserved.</p>
            <p>Need help? Contact us at support@speedycourier.com or 1-800-SPEEDY-1</p>
          </div>
        </div>
      </body>
      </html>
    `
  }

  private generateAdminAlertTemplate(message: string, details: any): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Admin Alert - Speedy Courier</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #dc2626; color: white; padding: 20px; text-align: center; }
          .content { padding: 20px; background: #f9f9f9; }
          .alert-info { background: white; padding: 15px; border-radius: 8px; margin: 15px 0; }
          .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🚨 Admin Alert</h1>
            <p>${message}</p>
          </div>
          
          <div class="content">
            <div class="alert-info">
              <h3>Alert Details:</h3>
              <pre>${JSON.stringify(details, null, 2)}</pre>
            </div>
            
            <p>Time: ${new Date().toISOString()}</p>
            <p>Please review and take appropriate action.</p>
          </div>
          
          <div class="footer">
            <p>Speedy Courier Admin System</p>
          </div>
        </div>
      </body>
      </html>
    `
  }
}

export const emailService = new EmailService()
