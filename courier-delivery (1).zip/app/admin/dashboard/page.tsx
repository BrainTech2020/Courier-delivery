"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Package, Truck, Users, BarChart3, Plus, Search, Filter, LogOut, Bell, Settings, MapPin, Clock, CheckCircle, AlertCircle, Send } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { SpeedyCourierLogo } from "@/components/speedy-courier-logo"
import { useToast } from "@/hooks/use-toast"
import { trackAdminLogin } from "@/components/google-analytics"
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Mock data for dashboard
const mockPackages = [
  {
    id: "FX123456789",
    from: "New York, NY",
    to: "Los Angeles, CA",
    status: "In Transit",
    statusColor: "bg-blue-500",
    customer: "John Doe",
    customerEmail: "john.doe@email.com",
    service: "Express Overnight",
    created: "2024-01-15",
    estimated: "2024-01-16"
  },
  {
    id: "FX987654321",
    from: "Miami, FL",
    to: "Atlanta, GA",
    status: "Delivered",
    statusColor: "bg-green-500",
    customer: "Jane Smith",
    customerEmail: "jane.smith@email.com",
    service: "Ground",
    created: "2024-01-14",
    estimated: "2024-01-15"
  },
  {
    id: "FX456789123",
    from: "Chicago, IL",
    to: "Houston, TX",
    status: "Pending",
    statusColor: "bg-yellow-500",
    customer: "Bob Johnson",
    customerEmail: "bob.johnson@email.com",
    service: "Express",
    created: "2024-01-15",
    estimated: "2024-01-17"
  },
  {
    id: "FX789123456",
    from: "Seattle, WA",
    to: "Denver, CO",
    status: "Out for Delivery",
    statusColor: "bg-orange-500",
    customer: "Alice Brown",
    customerEmail: "alice.brown@email.com",
    service: "Ground",
    created: "2024-01-13",
    estimated: "2024-01-15"
  }
]

export default function AdminDashboard() {
  const [adminUser, setAdminUser] = useState(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [packages, setPackages] = useState(mockPackages)
  const { toast } = useToast()
  const router = useRouter()

  useEffect(() => {
    // Check if user is authenticated
    const isAuth = localStorage.getItem("adminAuth")
    const user = localStorage.getItem("adminUser")
    
    if (!isAuth || isAuth !== "true") {
      router.push("/admin/login")
      return
    }
    
    if (user) {
      setAdminUser(JSON.parse(user))
      trackAdminLogin(true)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("adminAuth")
    localStorage.removeItem("adminUser")
    router.push("/admin/login")
  }

  const sendNotification = async (packageData, notificationType = 'package_update') => {
    try {
      const response = await fetch('/api/notifications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          type: notificationType,
          data: {
            trackingNumber: packageData.id,
            status: packageData.status,
            location: packageData.to,
            timestamp: new Date().toLocaleString(),
            description: `Package status updated to ${packageData.status}`,
            customerEmail: packageData.customerEmail,
            customerName: packageData.customer
          }
        }),
      })

      const result = await response.json()
      
      if (result.success) {
        toast({
          title: "📧 Notification Sent",
          description: `Email sent to ${packageData.customer} about package ${packageData.id}`,
        })
      }
    } catch (error) {
      console.error('Failed to send notification:', error)
      toast({
        title: "❌ Notification Failed",
        description: "Failed to send email notification",
        variant: "destructive"
      })
    }
  }

  const updatePackageStatus = (packageId, newStatus) => {
    setPackages(prev => prev.map(pkg => 
      pkg.id === packageId 
        ? { ...pkg, status: newStatus, statusColor: getStatusColor(newStatus) }
        : pkg
    ))
    
    const packageData = packages.find(pkg => pkg.id === packageId)
    if (packageData) {
      const updatedPackage = { ...packageData, status: newStatus }
      sendNotification(updatedPackage, newStatus === 'Delivered' ? 'delivery_confirmation' : 'package_update')
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'Delivered': return 'bg-green-500'
      case 'In Transit': return 'bg-blue-500'
      case 'Out for Delivery': return 'bg-orange-500'
      case 'Pending': return 'bg-yellow-500'
      default: return 'bg-gray-500'
    }
  }

  const filteredPackages = packages.filter(pkg =>
    pkg.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pkg.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pkg.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
    pkg.to.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const stats = {
    totalPackages: packages.length,
    inTransit: packages.filter(p => p.status === "In Transit").length,
    delivered: packages.filter(p => p.status === "Delivered").length,
    pending: packages.filter(p => p.status === "Pending").length
  }

  if (!adminUser) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <SpeedyCourierLogo className="h-8" />
              <Separator orientation="vertical" className="h-6" />
              <h1 className="text-xl font-semibold">Admin Dashboard</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-sm font-medium text-blue-600">
                        {adminUser.name.charAt(0)}
                      </span>
                    </div>
                    <span className="hidden md:block">{adminUser.name}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r min-h-screen">
          <nav className="p-4 space-y-2">
            <Button variant="ghost" className="w-full justify-start bg-blue-50 text-blue-600">
              <BarChart3 className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Package className="mr-2 h-4 w-4" />
              Packages
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Truck className="mr-2 h-4 w-4" />
              Vehicles
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Users className="mr-2 h-4 w-4" />
              Customers
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <MapPin className="mr-2 h-4 w-4" />
              Routes
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Bell className="mr-2 h-4 w-4" />
              Notifications
            </Button>
            <Button variant="ghost" className="w-full justify-start">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Packages</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.totalPackages}</div>
                <p className="text-xs text-muted-foreground">+12% from last month</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">In Transit</CardTitle>
                <Truck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.inTransit}</div>
                <p className="text-xs text-muted-foreground">Active deliveries</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Delivered</CardTitle>
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.delivered}</div>
                <p className="text-xs text-muted-foreground">Today</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.pending}</div>
                <p className="text-xs text-muted-foreground">Awaiting pickup</p>
              </CardContent>
            </Card>
          </div>

          {/* Packages Table */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Package Management</CardTitle>
                  <CardDescription>Manage and track all packages with automated email notifications</CardDescription>
                </div>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Package
                </Button>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search packages..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tracking ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>From</TableHead>
                    <TableHead>To</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPackages.map((pkg) => (
                    <TableRow key={pkg.id}>
                      <TableCell className="font-medium">{pkg.id}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{pkg.customer}</div>
                          <div className="text-sm text-gray-500">{pkg.customerEmail}</div>
                        </div>
                      </TableCell>
                      <TableCell>{pkg.from}</TableCell>
                      <TableCell>{pkg.to}</TableCell>
                      <TableCell>{pkg.service}</TableCell>
                      <TableCell>
                        <Badge className={`${pkg.statusColor} text-white`}>
                          {pkg.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{pkg.created}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => sendNotification(pkg)}
                          >
                            <Send className="h-3 w-3" />
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                •••
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuItem>View Details</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => updatePackageStatus(pkg.id, 'In Transit')}>
                                Mark In Transit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => updatePackageStatus(pkg.id, 'Out for Delivery')}>
                                Mark Out for Delivery
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => updatePackageStatus(pkg.id, 'Delivered')}>
                                Mark Delivered
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>Edit Package</DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600">
                                Delete Package
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
