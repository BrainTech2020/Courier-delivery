# 🚀 Speedy Courier - Vercel Deployment Guide

Complete step-by-step guide to deploy your Speedy Courier site to Vercel with all features enabled.

## 📋 Pre-Deployment Checklist

### ✅ Required Accounts
- [ ] GitHub account with repository
- [ ] Vercel account ([vercel.com](https://vercel.com))
- [ ] Google Analytics account ([analytics.google.com](https://analytics.google.com))
- [ ] SendGrid account ([sendgrid.com](https://sendgrid.com)) - Optional but recommended

### ✅ Required Information
- [ ] Google Analytics Measurement ID (G-XXXXXXXXXX)
- [ ] SendGrid API Key (SG.xxxxxxxxxx)
- [ ] Your domain email addresses
- [ ] Custom domain (optional)

## 🔧 Step 1: Prepare Your Repository

### Push to GitHub
\`\`\`bash
# Initialize git (if not already done)
git init
git add .
git commit -m "Initial commit - Speedy Courier site"

# Add remote and push
git remote add origin https://github.com/yourusername/speedy-courier.git
git branch -M main
git push -u origin main
\`\`\`

## 🌐 Step 2: Deploy to Vercel

### Option A: Automatic Deployment (Recommended)

1. **Go to Vercel Dashboard**
   - Visit [vercel.com](https://vercel.com)
   - Sign in with GitHub

2. **Import Project**
   - Click "New Project"
   - Select your GitHub repository
   - Click "Import"

3. **Configure Project**
   - **Project Name**: `speedy-courier`
   - **Framework Preset**: Next.js (auto-detected)
   - **Root Directory**: `./` (default)
   - **Build Command**: `npm run build` (default)
   - **Output Directory**: `.next` (default)

4. **Add Environment Variables**
   Click "Environment Variables" and add:
   \`\`\`
   NEXT_PUBLIC_GA_ID = G-XXXXXXXXXX
   EMAIL_API_KEY = your-sendgrid-api-key
   FROM_EMAIL = notifications@yourdomain.com
   ADMIN_EMAIL = admin@yourdomain.com
   SENDGRID_API_KEY = SG.xxxxxxxxxx
   \`\`\`

5. **Deploy**
   - Click "Deploy"
   - Wait for deployment to complete (2-3 minutes)
   - Your site will be live at `https://speedy-courier-xxx.vercel.app`

### Option B: CLI Deployment

\`\`\`bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# Follow prompts:
# ? Set up and deploy "~/speedy-courier"? [Y/n] y
# ? Which scope do you want to deploy to? [Your Account]
# ? Link to existing project? [y/N] n
# ? What's your project's name? speedy-courier
# ? In which directory is your code located? ./

# Add environment variables
vercel env add NEXT_PUBLIC_GA_ID production
vercel env add EMAIL_API_KEY production
vercel env add FROM_EMAIL production
vercel env add ADMIN_EMAIL production
vercel env add SENDGRID_API_KEY production

# Deploy to production
vercel --prod
\`\`\`

## 📊 Step 3: Configure Google Analytics

### Create Google Analytics Property

1. **Go to Google Analytics**
   - Visit [analytics.google.com](https://analytics.google.com)
   - Sign in with Google account

2. **Create Account**
   - Click "Start measuring"
   - Account name: "Speedy Courier"
   - Configure data sharing settings

3. **Create Property**
   - Property name: "Speedy Courier Website"
   - Time zone: Your timezone
   - Currency: Your currency

4. **Get Measurement ID**
   - Complete setup wizard
   - Copy your Measurement ID (G-XXXXXXXXXX)
   - Add to Vercel environment variables

### Verify Analytics Installation

1. **Real-time Reports**
   - Go to Analytics dashboard
   - Click "Realtime" → "Overview"
   - Visit your deployed site
   - Verify traffic appears in real-time

2. **Test Events**
   - Track a package on your site
   - Request a service quote
   - Check if custom events appear

## 📧 Step 4: Configure Email Service (SendGrid)

### Setup SendGrid

1. **Create SendGrid Account**
   - Visit [sendgrid.com](https://sendgrid.com)
   - Sign up for free account

2. **Verify Sender Identity**
   - Go to Settings → Sender Authentication
   - Verify your email address
   - Or set up domain authentication (recommended)

3. **Create API Key**
   - Go to Settings → API Keys
   - Click "Create API Key"
   - Name: "Speedy Courier Production"
   - Permissions: "Full Access" or "Mail Send"
   - Copy the API key (starts with SG.)

4. **Add to Vercel**
   - Go to Vercel project dashboard
   - Settings → Environment Variables
   - Add `SENDGRID_API_KEY` with your API key
   - Redeploy the project

### Test Email Functionality

1. **Admin Dashboard**
   - Go to `/admin/login`
   - Login with demo credentials
   - Try sending a notification
   - Check if emails are delivered

2. **Package Tracking**
   - Track a demo package
   - Verify notification emails are sent
   - Check SendGrid activity dashboard

## 🌐 Step 5: Custom Domain (Optional)

### Add Custom Domain

1. **In Vercel Dashboard**
   - Go to your project
   - Click "Domains" tab
   - Click "Add"
   - Enter your domain: `speedycourier.com`

2. **Configure DNS**
   Vercel will provide DNS records to add:
   \`\`\`
   Type: A
   Name: @
   Value: 76.76.19.61

   Type: CNAME
   Name: www
   Value: cname.vercel-dns.com
   \`\`\`

3. **Update Your DNS Provider**
   - Go to your domain registrar
   - Add the DNS records provided by Vercel
   - Wait for propagation (up to 24 hours)

### SSL Certificate

- Vercel automatically provides SSL certificates
- Your site will be available at `https://yourdomain.com`
- HTTP traffic automatically redirects to HTTPS

## 🔍 Step 6: Verification & Testing

### ✅ Deployment Checklist

- [ ] Site loads at Vercel URL
- [ ] All pages render correctly
- [ ] Package tracking works
- [ ] Admin login functions
- [ ] Email notifications send
- [ ] Analytics tracking active
- [ ] Mobile responsive
- [ ] SSL certificate active

### 🧪 Test All Features

1. **Homepage**
   - [ ] Hero section loads
   - [ ] Tracking form works
   - [ ] Service cards display
   - [ ] Footer links work

2. **Package Tracking**
   - [ ] Demo tracking numbers work
   - [ ] Results display correctly
   - [ ] Email notifications sent
   - [ ] Analytics events tracked

3. **Admin Dashboard**
   - [ ] Login page accessible
   - [ ] Authentication works
   - [ ] Package management functions
   - [ ] Notifications can be sent

4. **Analytics**
   - [ ] Page views tracked
   - [ ] Custom events recorded
   - [ ] Real-time data appears
   - [ ] Conversion goals set

## 🚨 Troubleshooting

### Common Issues

**Build Failures**
\`\`\`bash
# Check build logs in Vercel dashboard
# Common fixes:
- Ensure all dependencies in package.json
- Check TypeScript errors
- Verify environment variables
\`\`\`

**Environment Variables Not Working**
\`\`\`bash
# In Vercel dashboard:
1. Go to Settings → Environment Variables
2. Ensure all variables are set for "Production"
3. Redeploy after adding variables
\`\`\`

**Email Not Sending**
\`\`\`bash
# Check SendGrid setup:
1. Verify API key is correct
2. Confirm sender email is verified
3. Check SendGrid activity logs
4. Ensure FROM_EMAIL matches verified sender
\`\`\`

**Analytics Not Tracking**
\`\`\`bash
# Verify Google Analytics:
1. Check Measurement ID format (G-XXXXXXXXXX)
2. Ensure NEXT_PUBLIC_GA_ID is set correctly
3. Test in incognito mode
4. Check browser console for errors
\`\`\`

### Performance Optimization

**Lighthouse Scores**
- Run Lighthouse audit on deployed site
- Optimize images if needed
- Check Core Web Vitals
- Ensure accessibility compliance

**Monitoring**
- Set up Vercel Analytics (optional)
- Configure uptime monitoring
- Set up error tracking (Sentry)

## 🎉 Post-Deployment

### 🔧 Ongoing Maintenance

1. **Monitor Analytics**
   - Check Google Analytics weekly
   - Review user behavior
   - Track conversion rates

2. **Email Performance**
   - Monitor SendGrid delivery rates
   - Check bounce rates
   - Update templates as needed

3. **Security Updates**
   - Keep dependencies updated
   - Monitor Vercel security advisories
   - Regular backup of data

### 📈 Growth & Scaling

1. **Performance Monitoring**
   - Set up Vercel Analytics
   - Monitor Core Web Vitals
   - Track loading times

2. **Feature Additions**
   - Add more tracking statuses
   - Implement user accounts
   - Add payment integration

3. **SEO Optimization**
   - Submit sitemap to Google
   - Optimize meta descriptions
   - Add structured data

## 🎯 Success Metrics

Your deployment is successful when:

- ✅ Site loads in under 3 seconds
- ✅ All features work correctly
- ✅ Email notifications deliver
- ✅ Analytics data flows
- ✅ Mobile experience is smooth
- ✅ SEO score is 90+
- ✅ Security headers are set

## 📞 Support Resources

- **Vercel Documentation**: [vercel.com/docs](https://vercel.com/docs)
- **Next.js Documentation**: [nextjs.org/docs](https://nextjs.org/docs)
- **SendGrid Documentation**: [docs.sendgrid.com](https://docs.sendgrid.com)
- **Google Analytics Help**: [support.google.com/analytics](https://support.google.com/analytics)

---

🚀 **Your Speedy Courier site is now live and ready for customers!**

**Live URL**: `https://your-project.vercel.app`
**Admin Access**: `https://your-project.vercel.app/admin/login`
**Analytics**: Check your Google Analytics dashboard
