import React from 'react'

interface SpeedyCourierLogoProps {
  className?: string
  variant?: 'default' | 'white'
}

export function SpeedyCourierLogo({ className = "h-12", variant = 'default' }: SpeedyCourierLogoProps) {
  const primaryColor = variant === 'white' ? '#ffffff' : '#2563eb'
  const accentColor = variant === 'white' ? '#ffffff' : '#ea580c'
  const textColor = variant === 'white' ? '#ffffff' : '#1e40af'

  return (
    <svg
      viewBox="0 0 280 60"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Background circle for truck */}
      <circle cx="30" cy="30" r="28" fill={primaryColor} opacity="0.1" />
      
      {/* Delivery truck icon */}
      <g transform="translate(8, 15)">
        {/* Truck body */}
        <rect x="0" y="15" width="28" height="12" rx="2" fill={primaryColor} />
        <rect x="28" y="10" width="16" height="17" rx="2" fill={primaryColor} />
        
        {/* Truck cab window */}
        <rect x="30" y="12" width="12" height="8" rx="1" fill="white" opacity="0.9" />
        
        {/* Wheels */}
        <circle cx="10" cy="32" r="4" fill={textColor} />
        <circle cx="36" cy="32" r="4" fill={textColor} />
        <circle cx="10" cy="32" r="2" fill="white" />
        <circle cx="36" cy="32" r="2" fill="white" />
        
        {/* Speed lines */}
        <g stroke={accentColor} strokeWidth="2" strokeLinecap="round">
          <line x1="-2" y1="8" x2="6" y2="8" opacity="0.7" />
          <line x1="-4" y1="12" x2="4" y2="12" opacity="0.5" />
          <line x1="-2" y1="16" x2="6" y2="16" opacity="0.7" />
        </g>
      </g>
      
      {/* Company name */}
      <g>
        {/* "Speedy" text */}
        <text
          x="70"
          y="25"
          fontFamily="Arial, sans-serif"
          fontSize="18"
          fontWeight="bold"
          fill={textColor}
          letterSpacing="-0.5px"
        >
          Speedy
        </text>
        
        {/* "Courier" text */}
        <text
          x="70"
          y="45"
          fontFamily="Arial, sans-serif"
          fontSize="16"
          fontWeight="600"
          fill={primaryColor}
          letterSpacing="0.5px"
        >
          COURIER
        </text>
      </g>
      
      {/* Swoosh/speed element */}
      <path
        d="M 160 20 Q 200 15 240 25 Q 200 35 160 30 Z"
        fill={accentColor}
        opacity="0.8"
      />
      
      {/* Additional speed accent */}
      <path
        d="M 170 35 Q 200 30 230 38 Q 200 45 170 40 Z"
        fill={accentColor}
        opacity="0.4"
      />
      
      {/* Tagline */}
      <text
        x="70"
        y="55"
        fontFamily="Arial, sans-serif"
        fontSize="8"
        fill={variant === 'white' ? '#e5e7eb' : '#6b7280'}
        letterSpacing="1px"
      >
        FAST • RELIABLE • WORLDWIDE
      </text>
    </svg>
  )
}
