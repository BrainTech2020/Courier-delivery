import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { GoogleAnalytics } from '@/components/google-analytics'
import { Toaster } from '@/components/ui/toaster'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Speedy Courier - Fast, Reliable Delivery Worldwide',
  description: 'Track your packages in real-time and enjoy secure, on-time delivery to over 220 countries and territories. Express overnight, ground shipping, and international delivery services.',
  keywords: 'courier, delivery, shipping, tracking, express, overnight, international, package delivery, logistics',
  authors: [{ name: 'Speedy Courier' }],
  creator: 'Speedy Courier',
  publisher: 'Speedy Courier',
  robots: 'index, follow',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://speedycourier.com',
    title: 'Speedy Courier - Fast, Reliable Delivery Worldwide',
    description: 'Professional courier and delivery services with real-time tracking. Express overnight, ground shipping, and international delivery to 220+ countries.',
    siteName: 'Speedy Courier',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Speedy Courier - Fast, Reliable Delivery Worldwide',
    description: 'Professional courier and delivery services with real-time tracking.',
    creator: '@speedycourier',
  },
  viewport: 'width=device-width, initial-scale=1',
  themeColor: '#2563eb',
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="manifest" href="/site.webmanifest" />
      </head>
      <body className={inter.className}>
        <GoogleAnalytics />
        {children}
        <Toaster />
      </body>
    </html>
  )
}
